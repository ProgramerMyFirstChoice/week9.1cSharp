﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _9._1StructsVsClasses
{
    public partial class Form1 : Form
    {
     /* Nahom Gebreyohannies
     * 
     * Course CSI 154
     * 9.1 Structs vs Classes
     * Date 03/14/2018
     * Instructor Christy Hernadaze
     */
        // Create new random object
        Random rand = new Random();

        // Create a lists of Struct boxes
        List<StructBox> structBoxes1 = new List<StructBox>();
        List<StructBox> structBoxes2 = new List<StructBox>();
        List<StructBox> structBoxes3 = new List<StructBox>();
        List<StructBox> structBoxes4 = new List<StructBox>();
        List<StructBox> structBoxes5 = new List<StructBox>();

        // Create a lists of Class boxes
        List<ClassBox> classBoxes1 = new List<ClassBox>();
        List<ClassBox> classBoxes2 = new List<ClassBox>();
        List<ClassBox> classBoxes3 = new List<ClassBox>();
        List<ClassBox> classBoxes4 = new List<ClassBox>();
        List<ClassBox> classBoxes5 = new List<ClassBox>();

        public Form1()
        {
            InitializeComponent();
        }

        // struct box
        public struct StructBox
        {
            // fields
            private double _length;
            private double _width;
            private double _height;

            // parametrized constructor
            public StructBox(double length, double width, double height)
            {
                _length = length;
                _width = width;
                _height = height;
            }

            // Properties
            public double Length { get { return _length; } set { _length = value; } }

            public double Width { get { return _width; } set { _width = value; } }

            public double Height { get { return _height; } set { _height = value; } }

            // Methods calculate Volumne of the Box
            public double Volume()
            {
                return _length * _width * _height;
            }

            // Method calculate Area of the Box
            public double Area()
            {
                return 2 * (_length * _width) + 2 * (_length * _height) + 2 * (_width * _height);
            }
        }// End of StructBox

        // Class box
        public struct ClassBox
        {
            // fields
            private double _length;
            private double _width;
            private double _height;

            // parametrized constructor
            public ClassBox(double length, double width, double height)
            {
                _length = length;
                _width = width;
                _height = height;

            }

            // Properties
            public double Length { get { return _length; } set { _length = value; } }

            public double Width { get { return _width; } set { _width = value; } }

            public double Height { get { return _height; } set { _height = value; } }

            // Methods calculate Volumne of the Box
            public double Volume()
            {
                return _length * _width * _height;
            }

            // Method calculate Area of the Box
            public double Area()
            {
                return 2 * (_length * _width) + 2 * (_length * _height) + 2 * (_width * _height);
            }
        }// End of ClassBox

        // Click button display structboxes
        private void btnStruct_Click(object sender, EventArgs e)
        {
            // Create StructBox object(Struct object)
            double L = 1 + rand.NextDouble() + rand.Next(7, 11);
            double W = 1 + rand.NextDouble() + rand.Next(3, 7);
            double H = 1 + rand.NextDouble() + rand.Next(5, 9);

            // Create 5 list of random  structBoxes
            StructBox box1 = new StructBox(L, W, H);
            StructBox box2 = box1;
            StructBox box3 = new StructBox(L + 2, W + 3, H + 4);
            StructBox box4 = new StructBox(L + 3, W + 4, H + 5);
            StructBox box5 = new StructBox(L + 1, W + 3, H + 6);

            // Save the box dimension to list
            structBoxes1.Add(box1);
            structBoxes2.Add(box2);
            structBoxes3.Add(box3);
            structBoxes4.Add(box4);
            structBoxes5.Add(box5);

            // Display the list from the boxes
            richTextBox1.Text = "Struct box1:\n";
            DisplayStructBox(box1);
            richTextBox1.AppendText("Struct box2:\n");
            DisplayStructBox(box2);
            richTextBox1.AppendText("Struct box3:\n");
            DisplayStructBox(box3);
            richTextBox1.AppendText("Struct box4:\n");
            DisplayStructBox(box4);
            richTextBox1.AppendText("Struct box5:\n");
            DisplayStructBox(box5);

            // Change the value of the property in box1 to check
            // whether it affect box2
            box1.Length = 13.9;
            box1.Width = 9.5;
            box1.Height = 5.6;

            // Display box1 And box2 2 should be same as 1
            richTextBox1.AppendText("\nAfter making change to box1:\n");
            richTextBox1.AppendText( "box1:\n");
            // Select the text use the SelectionFont and/or SelectionColor property
            // to change the color, font, and size of the text:
            richTextBox1.SelectionFont = new Font("New Time Roman", 12, FontStyle.Regular);
            richTextBox1.SelectionColor = Color.Red;
            DisplayStructBox(box1);
            richTextBox1.AppendText("box2:\n");           
            DisplayStructBox(box2);

        }

        // Click button display classBoexes
        private void btnClass_Click(object sender, EventArgs e)
        {
            // Create StructBox object(Struct object)
            double L = 1 + rand.NextDouble() + rand.Next(7, 11);
            double W = 1 + rand.NextDouble() + rand.Next(3, 7);
            double H = 1 + rand.NextDouble() + rand.Next(5, 9);

            // Create 5 list of random  structBoxes
            ClassBox box1 = new ClassBox(L, W, H);
            ClassBox box2 = box1;
            ClassBox box3 = new ClassBox(L + 2, W + 3, H + 4);
            ClassBox box4 = new ClassBox(L + 3, W + 4, H + 5);
            ClassBox box5 = new ClassBox(L + 1, W + 3, H + 6);

            // Save the box dimension to list
            classBoxes1.Add(box1);
            classBoxes2.Add(box2);
            classBoxes3.Add(box3);
            classBoxes4.Add(box4);
            classBoxes5.Add(box5);

            // Display the list from the boxes
            richTextBox1.Text = "Struct box1:\n";
            DisplayClassBox(box1);
            richTextBox1.AppendText("Struct box2:\n");
            DisplayClassBox(box2);
            richTextBox1.AppendText("Struct box3:\n");
            DisplayClassBox(box3);
            richTextBox1.AppendText("Struct box4:\n");
            DisplayClassBox(box4);
            richTextBox1.AppendText("Struct box5:\n");
            DisplayClassBox(box5);


            // Change the value of the property in box1 to check
            // whether it affect box2
            box1.Length = 13.9;
            box1.Width = 9.5;
            box1.Height = 5.6;

            // Display box1 And box2 2 should be same as 1
            richTextBox1.AppendText("\nAfter making to box1:\n");
            richTextBox1.AppendText("box1:\n");

            // Select the text use the SelectionFont and/or SelectionColor property
            // to change the color, font, and size of the text:
            richTextBox1.SelectionFont = new Font("New Time Roman", 12, FontStyle.Regular);
            richTextBox1.SelectionColor = Color.Red;
            DisplayClassBox(box1);
            richTextBox1.AppendText("box2:\n");

            
            DisplayClassBox(box2);
        }

        // Display struct method
        private void DisplayStructBox(StructBox sBox)
        {
            richTextBox1.AppendText(
                "lenght = " + sBox.Length.ToString("f2").PadRight(8) +
                "width = " + sBox.Width.ToString("f2").PadRight(8) +
                "height = " + sBox.Height.ToString("f2").PadRight(8) +
                "area = " + sBox.Area().ToString("f2").PadRight(8) +
                "volume = " + sBox.Volume().ToString("f2").PadRight(8) +
                "\n");
        }

        // Display struct method
        private void DisplayClassBox(ClassBox cBox)
        {
            richTextBox1.AppendText(
                "lenght = " + cBox.Length.ToString("f2").PadRight(11) +
                "width = " + cBox.Width.ToString("f2").PadRight(11) +
                "height = " + cBox.Height.ToString("f2").PadRight(11) +
                "area = " + cBox.Area().ToString("f2").PadRight(11) +
                "volume = " + cBox.Volume().ToString("f2").PadRight(11) +
                "\n");
        }

    }
}
